var offscreenReady = null;

function ensureOffscreen() {
  if (offscreenReady) return offscreenReady;
  offscreenReady = chrome.offscreen.hasDocument().then(function (exists) {
    if (exists) return;
    return chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['USER_MEDIA', 'AUDIO_PLAYBACK'],
      justification: 'Ouve o áudio da reunião do Meet para transcrever, sem usar a legenda.',
    });
  }).catch(function (error) {
    offscreenReady = null;
    throw error;
  });
  return offscreenReady;
}

function toOffscreen(message) {
  return ensureOffscreen().then(function () {
    return new Promise(function (resolve) {
      chrome.runtime.sendMessage(message, function (res) {
        void chrome.runtime.lastError;
        resolve(res || null);
      });
    });
  });
}

function streamIdFor(tabId) {
  return new Promise(function (resolve, reject) {
    chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, function (streamId) {
      var err = chrome.runtime.lastError && chrome.runtime.lastError.message;
      if (err || !streamId) reject(new Error(err || 'sem áudio'));
      else resolve(streamId);
    });
  });
}

function listenTab(tabId) {
  return streamIdFor(tabId).catch(function () {
    return toOffscreen({ type: 'parar-audio' }).then(function () { return streamIdFor(tabId); });
  }).then(function (streamId) {
    return toOffscreen({ type: 'tab-stream', streamId: streamId, tabId: tabId });
  });
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || !message.type) return;
  if (message.type === 'ouvir-sala' && sender.tab && sender.tab.id) {
    listenTab(sender.tab.id).then(function (res) {
      sendResponse({ ok: !!(res && res.ok), error: res && res.error });
    }).catch(function (error) {
      sendResponse({ ok: false, error: error && error.message });
    });
    return true;
  }
  if (message.type === 'audio-sala' && message.tabId) {
    chrome.tabs.sendMessage(message.tabId, message, function () { void chrome.runtime.lastError; });
    return;
  }
  if (message.type === 'parar-audio' && sender.tab) {
    toOffscreen({ type: 'parar-audio' }).catch(function () {});
    sendResponse({ ok: true });
  }
});
