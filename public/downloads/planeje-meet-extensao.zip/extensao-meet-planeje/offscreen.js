var stream = null;
var audioCtx = null;
var tabId = 0;
var meter = 0;
var phrase = null;

function levelOf(analyser, data) {
  analyser.getByteTimeDomainData(data);
  var sum = 0;
  for (var i = 0; i < data.length; i += 1) {
    var v = (data[i] - 128) / 128;
    sum += v * v;
  }
  return Math.sqrt(sum / data.length);
}

function stop() {
  clearInterval(meter);
  meter = 0;
  if (phrase && phrase.state !== 'inactive') {
    try { phrase.stop(); } catch (error) { /* já parado */ }
  }
  phrase = null;
  if (stream) {
    stream.getTracks().forEach(function (track) { track.stop(); });
    stream = null;
  }
  if (audioCtx) {
    audioCtx.close().catch(function () {});
    audioCtx = null;
  }
}

function capture(streamId) {
  return navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: false,
  });
}

function blobToBase64(blob) {
  return new Promise(function (resolve, reject) {
    var reader = new FileReader();
    reader.onload = function () { resolve(String(reader.result).split(',')[1] || ''); };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function deliver(blob, inicio, fim) {
  blobToBase64(blob).then(function (b64) {
    if (!b64) return;
    chrome.runtime.sendMessage({
      type: 'audio-sala',
      tabId: tabId,
      b64: b64,
      mime: blob.type || 'audio/webm',
      inicio: inicio,
      fim: fim,
    }, function () { void chrome.runtime.lastError; });
  }).catch(function () {});
}

async function start(streamId, nextTabId) {
  stop();
  tabId = nextTabId;
  stream = await capture(streamId);
  audioCtx = new AudioContext();
  await audioCtx.resume();
  var source = audioCtx.createMediaStreamSource(stream);
  source.connect(audioCtx.destination);
  var analyser = audioCtx.createAnalyser();
  analyser.fftSize = 2048;
  source.connect(analyser);
  var data = new Uint8Array(analyser.fftSize);
  var mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm';
  var noise = 0.004;
  var silenceMs = 0;
  var voicedMs = 0;
  var startedAt = 0;

  function finishPhrase() {
    if (!phrase) return;
    var rec = phrase;
    rec._voiced = voicedMs;
    rec._fim = Date.now();
    phrase = null;
    voicedMs = 0;
    silenceMs = 0;
    try { rec.stop(); } catch (error) { /* já parado */ }
  }

  function openPhrase() {
    var rec = new MediaRecorder(stream, { mimeType: mime, audioBitsPerSecond: 64000 });
    var chunks = [];
    rec._inicio = Date.now() - 300;
    rec.ondataavailable = function (event) {
      if (event.data && event.data.size) chunks.push(event.data);
    };
    rec.onstop = function () {
      if ((rec._voiced || 0) < 300) return;
      var blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
      if (blob.size < 400) return;
      deliver(blob, rec._inicio, rec._fim || Date.now());
    };
    try {
      rec.start();
      phrase = rec;
      startedAt = Date.now();
    } catch (error) {
      phrase = null;
    }
  }

  meter = setInterval(function () {
    if (!stream) return;
    var level = levelOf(analyser, data);
    var gate = Math.max(0.012, noise * 3);
    if (level >= gate) {
      silenceMs = 0;
      voicedMs += 100;
      if (!phrase) openPhrase();
      else if (Date.now() - startedAt > 25000) {
        finishPhrase();
        openPhrase();
      }
    } else {
      if (!phrase) noise = noise * 0.97 + level * 0.03;
      else {
        silenceMs += 100;
        if (silenceMs >= 900) finishPhrase();
      }
    }
  }, 100);
}

chrome.runtime.onMessage.addListener(function (message, _sender, sendResponse) {
  if (!message) return;
  if (message.type === 'parar-audio') {
    stop();
    sendResponse({ ok: true });
    return;
  }
  if (message.type !== 'tab-stream' || !message.streamId) return;
  start(message.streamId, message.tabId).then(function () {
    sendResponse({ ok: true });
  }).catch(function (error) {
    sendResponse({ ok: false, error: String((error && error.message) || error) });
  });
  return true;
});
