# Planeje Reuniões

Extensão do Chrome que ouve a reunião do Google Meet e grava as falas na reunião do cliente.

1. Baixe o zip e descompacte.
2. No Chrome, abra `chrome://extensions`, ligue o modo do desenvolvedor e escolha Carregar sem compactação na pasta `extensao-meet-planeje`.
3. Entre no Planeje neste mesmo Chrome.
4. Na ficha do cliente, use Criar e abrir sala, ou cole um link que já exista.
5. Na sala, a coluna Transcrição ao vivo mostra o que foi falado, sem ligar a legenda do Meet. Parar encerra a transcrição na ficha. Depois de atualizar o zip, recarregue a extensão em chrome://extensions e atualize a aba do Meet.
