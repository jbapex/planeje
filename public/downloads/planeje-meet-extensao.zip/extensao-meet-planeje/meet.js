(function meetCapture() {
  var PLANEJE = 'https://planeje.jbapex.com.br';
  var ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzg4NzA1OTYxLCJleHAiOjE5NDYzODU5NjF9.TWwmp9YbLQcAJrtq7eGNPp8cbh460AmLZIp6gBdsST8';
  var FUNCTION_URL = PLANEJE + '/functions/v1/reuniao-audio';
  var MERGE_GAP_MS = 4000;
  var HEAD_WAIT_MS = 25000;
  var MAX_PARALLEL = 3;
  var api = globalThis.PlanejeReuniao;

  var reuniao = null;
  var lastCode = '';
  var stopped = true;
  var finishing = false;
  var lines = [];
  var nextOrdem = 0;
  var slots = [];
  var slotSeq = 0;
  var running = 0;
  var saving = false;
  var roomAudioOn = false;
  var speakerLog = [];
  var lastSpeakerName = '';
  var lastSpeakerAt = 0;
  var livePreview = null;
  var capStates = [];
  var recentCaptions = [];
  var lastCaptionTry = 0;
  var attachedAt = 0;
  var micMuted = false;

  var bar = document.createElement('div');
  bar.id = 'planeje-meet-bar';
  bar.innerHTML = '<div class="planeje-meet-head"><div class="planeje-meet-title"><strong>Transcrição ao vivo</strong><button type="button" class="planeje-meet-fold">Recolher</button></div><span class="planeje-meet-lang">Português (Brasil)</span><div class="planeje-meet-tools"><span class="planeje-meet-msg">Procurando a reunião…</span><button type="button" class="planeje-meet-stop">Parar</button></div></div><div class="planeje-meet-lines"></div>';
  var style = document.createElement('style');
  style.textContent = [
    '#planeje-meet-bar{position:fixed;top:12px;right:12px;width:min(380px,calc(100vw - 24px));height:min(640px,calc(100vh - 24px));',
    'z-index:2147483646;display:flex;flex-direction:column;background:#1f1f1f;color:#e8eaed;',
    'border:1px solid #3c4043;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.45);overflow:hidden;',
    'font:15px/1.45 Roboto,Arial,sans-serif}',
    '#planeje-meet-bar .planeje-meet-head{display:flex;flex-direction:column;gap:8px;padding:14px 14px 10px;cursor:grab;user-select:none}',
    '#planeje-meet-bar.planeje-dragging .planeje-meet-head{cursor:grabbing}',
    '#planeje-meet-bar .planeje-meet-title{display:flex;align-items:center;justify-content:space-between;gap:8px}',
    '#planeje-meet-bar .planeje-meet-fold{border:0;background:transparent;color:#8ab4f8;font-weight:700;cursor:pointer;padding:4px 0}',
    '#planeje-meet-bar[data-collapsed="1"]{width:auto;height:auto;min-width:220px}',
    '#planeje-meet-bar[data-collapsed="1"] .planeje-meet-lang,#planeje-meet-bar[data-collapsed="1"] .planeje-meet-tools,#planeje-meet-bar[data-collapsed="1"] .planeje-meet-lines{display:none}',
    '#planeje-meet-bar strong{display:block;font-size:16px;font-weight:600}',
    '#planeje-meet-bar .planeje-meet-lang{align-self:flex-start;padding:6px 10px;border-radius:8px;background:#394457;color:#d2e3fc;font-size:13px}',
    '#planeje-meet-bar .planeje-meet-tools{display:flex;gap:8px;align-items:center}',
    '#planeje-meet-bar .planeje-meet-msg{flex:1;font-size:12px;color:#9aa0a6}',
    '#planeje-meet-bar .planeje-meet-stop{border:0;border-radius:999px;background:#8ab4f8;color:#202124;font-weight:700;padding:6px 12px;cursor:pointer}',
    '#planeje-meet-bar[data-idle="1"] .planeje-meet-stop{display:none}',
    '#planeje-meet-bar .planeje-meet-lines{flex:1;overflow:auto;padding:8px 20px 24px}',
    '#planeje-meet-bar .who{margin:16px 0 4px;color:#81c995;font-weight:600;font-size:14px}',
    '#planeje-meet-bar .line{margin:0 0 10px;color:#e8eaed}',
    '#planeje-meet-bar .line.open{color:#9aa0a6;font-style:italic}',
    '#planeje-meet-bar .empty{color:#9aa0a6}',
    '[role="region"][aria-label*="egenda" i],[role="region"][aria-label*="aption" i]{opacity:0!important;pointer-events:none!important}',
  ].join('');
  document.documentElement.appendChild(style);
  document.documentElement.appendChild(bar);
  var message = bar.querySelector('.planeje-meet-msg');
  var linesEl = bar.querySelector('.planeje-meet-lines');
  var stopButton = bar.querySelector('.planeje-meet-stop');
  var foldButton = bar.querySelector('.planeje-meet-fold');
  var head = bar.querySelector('.planeje-meet-head');
  var drag = null;

  foldButton.addEventListener('click', function () {
    var collapsed = bar.dataset.collapsed === '1';
    bar.dataset.collapsed = collapsed ? '0' : '1';
    foldButton.textContent = collapsed ? 'Recolher' : 'Abrir';
  });

  head.addEventListener('pointerdown', function (event) {
    if (event.target.closest('button')) return;
    var rect = bar.getBoundingClientRect();
    drag = { dx: event.clientX - rect.left, dy: event.clientY - rect.top };
    bar.classList.add('planeje-dragging');
    bar.style.right = 'auto';
    bar.style.left = rect.left + 'px';
    bar.style.top = rect.top + 'px';
    head.setPointerCapture(event.pointerId);
  });
  head.addEventListener('pointermove', function (event) {
    if (!drag) return;
    var x = Math.max(0, Math.min(window.innerWidth - bar.offsetWidth, event.clientX - drag.dx));
    var y = Math.max(0, Math.min(window.innerHeight - 48, event.clientY - drag.dy));
    bar.style.left = x + 'px';
    bar.style.top = y + 'px';
  });
  function endDrag() {
    drag = null;
    bar.classList.remove('planeje-dragging');
  }
  head.addEventListener('pointerup', endDrag);
  head.addEventListener('pointercancel', endDrag);

  function esc(value) {
    return String(value || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function renderLines() {
    var items = lines.slice();
    var pendingMine = slots.some(function (slot) { return slot.source === 'mic' && slot.status !== 'done'; });
    if (livePreview) items.push({ speaker: livePreview.speaker, text: 'falando…', open: true });
    else if (pendingMine) items.push({ speaker: myName(), text: 'transcrevendo…', open: true });
    var html = '';
    var last = '';
    for (var i = 0; i < items.length; i += 1) {
      if (items[i].speaker !== last) {
        html += '<p class="who">' + esc(items[i].speaker) + '</p>';
        last = items[i].speaker;
      }
      html += '<p class="line' + (items[i].open ? ' open' : '') + '">' + esc(items[i].text) + '</p>';
    }
    if (!html) html = '<p class="empty">Ouvindo a reunião. Cada fala aparece aqui com o nome de quem falou.</p>';
    var nearBottom = linesEl.scrollHeight - linesEl.scrollTop - linesEl.clientHeight < 80;
    linesEl.innerHTML = html;
    if (nearBottom) linesEl.scrollTop = linesEl.scrollHeight;
  }
  renderLines();

  var baseMessage = '';
  function setMessage(text, idle) {
    baseMessage = text;
    bar.dataset.idle = idle ? '1' : '0';
    refreshMessage();
  }
  function refreshMessage() {
    var waiting = slots.filter(function (slot) { return slot.status !== 'done'; }).length;
    var unsaved = lines.filter(function (line) { return line.dirty; }).length;
    var extra = [];
    if (micMuted && reuniao && !stopped) extra.push('seu microfone está mudo, não gravo você');
    if (waiting) extra.push(waiting + (waiting === 1 ? ' trecho' : ' trechos') + ' na fila');
    if (unsaved) extra.push(unsaved + ' a gravar');
    message.textContent = baseMessage + (extra.length ? ' · ' + extra.join(' · ') : '');
  }

  function storageGet(keys) {
    return new Promise(function (resolve) { chrome.storage.local.get(keys, resolve); });
  }

  function wait(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  async function sessionToken() {
    var stored = await storageGet(['planejeSession']);
    var session = stored.planejeSession;
    if (!session || !session.access_token) return '';
    if (session.expires_at && Number(session.expires_at) * 1000 < Date.now() + 15000) return '';
    return session.access_token;
  }

  async function rest(token, path, options) {
    var response = await fetch(PLANEJE + '/rest/v1/' + path, {
      method: options.method || 'GET',
      headers: Object.assign({ apikey: ANON, Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, options.headers || {}),
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
    var text = await response.text();
    var data = null;
    try { data = text ? JSON.parse(text) : null; } catch (error) { data = { message: text.slice(0, 180) }; }
    if (!response.ok) {
      var err = new Error((data && (data.message || data.error)) || 'Falha ao falar com o Planeje');
      err.status = response.status;
      throw err;
    }
    return data;
  }

  async function callFunction(acao, body, isForm) {
    var headers = { apikey: ANON };
    if (reuniao && reuniao.chave) headers['x-reuniao-chave'] = reuniao.chave;
    var token = await sessionToken();
    if (token) headers.Authorization = 'Bearer ' + token;
    if (!isForm) headers['Content-Type'] = 'application/json';
    var response = await fetch(FUNCTION_URL + '?acao=' + acao, {
      method: 'POST',
      headers: headers,
      body: isForm ? body : JSON.stringify(body || {}),
    });
    var data = await response.json().catch(function () { return {}; });
    if (!response.ok) {
      var err = new Error((data && data.error) || 'Falha na transcrição');
      err.status = response.status;
      throw err;
    }
    return data;
  }

  async function ensureKey() {
    if (!reuniao) return false;
    var left = reuniao.chaveExp ? reuniao.chaveExp * 1000 - Date.now() : 0;
    if (reuniao.chave && left > 30 * 60 * 1000) return true;
    var token = await sessionToken();
    if (!token) return !!(reuniao.chave && left > 0);
    try {
      var data = await callFunction('chave', { reuniao_id: reuniao.id });
      reuniao.chave = data.chave;
      reuniao.chaveExp = data.expira;
      if (data.nome) reuniao.planejeName = data.nome;
      return true;
    } catch (error) {
      return !!(reuniao.chave && left > 0);
    }
  }

  function cleanName(value) {
    var name = String(value || '').replace(/\s+/g, ' ').trim();
    name = name.replace(/\s*\((você|you|tu|tú)\)\s*/gi, ' ').replace(/\s+/g, ' ').trim();
    if (name.length < 2 || name.length > 60) return '';
    if (/^[\d\s:+-]+$/.test(name)) return '';
    if (/microfone|câmera|camera|legenda|fixar|desafixar|opções|opcoes|apresent|participant|reação|reacao|silenc/i.test(name)) return '';
    if (/^(você|voce|you|pin|mute|unmute)$/i.test(name)) return '';
    return name;
  }

  function meetSelfName() {
    var marked = document.querySelector('[data-self-name]');
    var clean = cleanName(marked && marked.getAttribute('data-self-name'));
    if (clean) return clean;
    var nodes = document.querySelectorAll('[aria-label]');
    for (var i = 0; i < nodes.length; i += 1) {
      var match = (nodes[i].getAttribute('aria-label') || '').match(/^(.{2,80}?)\s*\((você|you|tu|tú)\)/i);
      if (match && cleanName(match[1])) return cleanName(match[1]);
    }
    return '';
  }

  function myName() {
    return meetSelfName() || (reuniao && reuniao.planejeName) || 'Você';
  }

  function nameFromAria(label) {
    var patterns = [
      /^(?:Fixar|Pin)\s+(.+?)\s+(?:na sua tela principal|na tela principal|to your main screen)/i,
      /^(?:Desafixar|Unpin)\s+(.+?)(?:\s+da sua tela principal|\s+from your main screen)?$/i,
      /^(?:Mais opções (?:de|para)|More options for)\s+(.+)$/i,
      /^(?:Silenciar|Mute)\s+(.+)$/i,
    ];
    for (var i = 0; i < patterns.length; i += 1) {
      var match = String(label || '').match(patterns[i]);
      if (match && cleanName(match[1])) return cleanName(match[1]);
    }
    return '';
  }

  function nameFromTile(tile) {
    if (!tile) return '';
    if (tile.getAttribute && cleanName(tile.getAttribute('data-self-name'))) return cleanName(tile.getAttribute('data-self-name'));
    var nested = tile.querySelector && tile.querySelector('[data-self-name]');
    if (nested && cleanName(nested.getAttribute('data-self-name'))) return cleanName(nested.getAttribute('data-self-name'));
    var labelled = tile.querySelectorAll ? tile.querySelectorAll('[aria-label]') : [];
    for (var i = 0; i < labelled.length; i += 1) {
      var fromAria = nameFromAria(labelled[i].getAttribute('aria-label'));
      if (fromAria) return fromAria;
    }
    var chip = tile.querySelector && tile.querySelector('span.notranslate');
    if (chip && cleanName(chip.textContent)) return cleanName(chip.textContent);
    var walker = document.createTreeWalker(tile, NodeFilter.SHOW_TEXT);
    var node;
    while ((node = walker.nextNode())) {
      var text = (node.textContent || '').trim();
      if (!cleanName(text) || /^\((você|you)\)$/i.test(text)) continue;
      var parent = node.parentElement;
      if (parent && parent.closest && parent.closest('button, [role="button"]')) continue;
      return cleanName(text);
    }
    return '';
  }

  function activeSpeakerName() {
    var marks = document.querySelectorAll('.kssMZb');
    for (var i = 0; i < marks.length; i += 1) {
      var tile = marks[i].closest ? (marks[i].closest('[data-participant-id]') || marks[i]) : marks[i];
      var name = nameFromTile(tile);
      if (name) return name;
    }
    return '';
  }

  function noteSpeaker() {
    var now = Date.now();
    var name = activeSpeakerName();
    if (!name && lastSpeakerName && now - lastSpeakerAt < 3000) name = lastSpeakerName;
    if (!name) return;
    lastSpeakerName = name;
    lastSpeakerAt = now;
    speakerLog.push({ t: now, name: name });
    if (speakerLog.length > 600) speakerLog.splice(0, speakerLog.length - 600);
  }

  function remoteSpeakerFor(start, end) {
    var mine = meetSelfName();
    var name = api.dominantSpeaker(speakerLog, start - 800, end + 300, mine);
    if (name) return name;
    for (var i = speakerLog.length - 1; i >= 0; i -= 1) {
      if (speakerLog[i].t < start - 15000) break;
      if (speakerLog[i].name !== mine) return speakerLog[i].name;
    }
    return 'Participante';
  }

  function norm(text) {
    return String(text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function looksSame(a, b) {
    var x = norm(a);
    var y = norm(b);
    if (!x || !y) return false;
    if (x === y) return true;
    return x.length > 12 && y.length > 12 && (x.indexOf(y) >= 0 || y.indexOf(x) >= 0);
  }

  function captionRegion() {
    var region = document.querySelector('[role="region"][aria-label*="egenda" i], [role="region"][aria-label*="aption" i]');
    return region && !bar.contains(region) ? region : null;
  }

  function ensureCaptions() {
    if (captionRegion() || Date.now() - lastCaptionTry < 4000) return;
    lastCaptionTry = Date.now();
    var buttons = document.querySelectorAll('button[aria-label]');
    for (var i = 0; i < buttons.length; i += 1) {
      var label = buttons[i].getAttribute('aria-label') || '';
      if (!/^(ativar|turn on|mostrar|show)\b/i.test(label) || !/legenda|caption/i.test(label)) continue;
      if (buttons[i].getAttribute('aria-pressed') === 'true') continue;
      buttons[i].click();
      return;
    }
  }

  function firstTextElement(block) {
    var walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT);
    var node;
    while ((node = walker.nextNode())) {
      if ((node.textContent || '').trim()) return node.parentElement;
    }
    return null;
  }

  function captionBlocks(region) {
    var blocks = [];
    var imgs = region.querySelectorAll('img');
    for (var i = 0; i < imgs.length; i += 1) {
      var block = imgs[i].parentElement;
      while (block && block !== region) {
        var nameEl = firstTextElement(block);
        var full = (block.textContent || '').replace(/\s+/g, ' ').trim();
        var name = nameEl ? (nameEl.textContent || '').replace(/\s+/g, ' ').trim() : '';
        if (name && full.length > name.length + 1) break;
        block = block.parentElement;
      }
      if (!block || block === region || blocks.some(function (item) { return item.el === block; })) continue;
      var nameNode = firstTextElement(block);
      var speaker = (nameNode.textContent || '').replace(/\s+/g, ' ').trim();
      var whole = (block.textContent || '').replace(/\s+/g, ' ').trim();
      var at = whole.indexOf(speaker);
      var text = (at >= 0 ? whole.slice(at + speaker.length) : whole).trim();
      if (speaker && text) blocks.push({ el: block, speaker: speaker, text: text });
    }
    if (!blocks.length) {
      region.querySelectorAll('.nMcdL, .TBMuR').forEach(function (el) {
        var nameEl = el.querySelector('.NWpY1d, .KcIKyf, .zs7s8d');
        var textEl = el.querySelector('.ygicle, .bh44bd, .iTTPOb');
        var who = nameEl ? nameEl.textContent.replace(/\s+/g, ' ').trim() : '';
        var said = textEl ? textEl.textContent.replace(/\s+/g, ' ').trim() : '';
        if (who && said) blocks.push({ el: el, speaker: who, text: said });
      });
    }
    return blocks;
  }

  function isSelfCaption(speaker) {
    return /^(você|voce|you|tu)$/i.test(speaker) || speaker === meetSelfName();
  }

  function commitCaption(state, now, force) {
    var delta = api.captionDelta(state.committed, state.text);
    if (!delta) return;
    var words = delta.split(' ');
    var part = delta;
    if (!force && now - state.changedAt < 1800) {
      if (words.length < 30) return;
      part = words.slice(0, -5).join(' ');
    }
    state.committed = (state.committed ? state.committed + ' ' : '') + part;
    var inicio = state.lastAt || state.firstAt;
    state.lastAt = now;
    var self = isSelfCaption(state.speaker);
    if (self && mic.stream) return;
    var speaker = self ? myName() : state.speaker;
    recentCaptions.push({ t: now, speaker: speaker, text: part });
    if (recentCaptions.length > 80) recentCaptions.splice(0, recentCaptions.length - 80);
    dropMicEcho(part, inicio, now);
    addText('legenda', speaker, part, inicio, now);
  }

  function readCaptions(force) {
    var now = Date.now();
    var region = captionRegion();
    var blocks = region ? captionBlocks(region) : [];
    var alive = [];
    blocks.forEach(function (block) {
      var state = capStates.find(function (item) { return item.el === block.el; });
      if (!state) {
        state = { el: block.el, speaker: block.speaker, text: '', committed: '', changedAt: now, firstAt: now, lastAt: 0 };
        capStates.push(state);
      }
      state.speaker = block.speaker;
      if (block.text !== state.text) {
        state.text = block.text;
        state.changedAt = now;
      }
      alive.push(state);
      commitCaption(state, now, force);
    });
    capStates.filter(function (state) { return alive.indexOf(state) < 0; }).forEach(function (state) {
      commitCaption(state, now, true);
    });
    capStates = alive;
  }

  function liveOtherCaption(start, end) {
    var texts = [];
    capStates.forEach(function (state) {
      if (!isSelfCaption(state.speaker) && state.changedAt >= start - 8000) texts.push(state.text);
    });
    recentCaptions.forEach(function (item) {
      if (item.speaker !== myName() && item.t >= start - 8000 && item.t <= end + 12000) texts.push(item.text);
    });
    return texts.join(' ');
  }

  function dropMicEcho(text, inicio, fim) {
    for (var i = lines.length - 1; i >= 0; i -= 1) {
      var line = lines[i];
      if (Number(line.fim) < inicio - 15000) break;
      if (line.source !== 'mic' || api.wordOverlap(line.text, text) < 0.6) continue;
      lines.splice(i, 1);
      if (line.saved) removeSaved(line.ordem);
      persistDirty();
    }
  }

  function removeSaved(ordem) {
    ensureKey().then(function (ok) {
      if (ok) return callFunction('fala', { ordem: ordem, apagar: true });
      return null;
    }).catch(function () { /* fica a fala */ });
  }

  function isJunk(text) {
    return /^(obrigad[oa]( por assistir)?\.?|legendas? pela comunidade.*|inscreva-se.*|thanks for watching.*|amém\.?|tchau\.?|\.+|…)$/i.test(text);
  }

  function echoOfOther(line) {
    for (var i = lines.length - 1; i >= 0 && i >= lines.length - 6; i -= 1) {
      var other = lines[i];
      if (other.source === line.source) continue;
      if (Math.abs(Number(other.inicio) - Number(line.inicio)) > 10000) continue;
      if (looksSame(other.text, line.text)) return true;
    }
    return false;
  }

  function persistDirty() {
    if (!reuniao) return;
    var pending = lines.filter(function (line) { return line.dirty; }).map(function (line) {
      return { ordem: line.ordem, speaker: line.speaker, text: line.text, inicio: line.inicio, fim: line.fim, source: line.source };
    });
    var key = 'planejeFalasPendentes:' + reuniao.id;
    var payload = {};
    payload[key] = pending;
    try { chrome.storage.local.set(payload); } catch (error) { /* sem storage */ }
  }

  function addText(source, speaker, text, inicio, fim) {
    var clean = String(text || '').replace(/\s+/g, ' ').trim();
    if (!clean || !/[0-9A-Za-zÀ-ÿ]/.test(clean) || isJunk(clean)) return;
    var candidate = { source: source, speaker: speaker, text: clean, inicio: inicio, fim: fim };
    if (echoOfOther(candidate)) return;
    var prev = lines.length ? lines[lines.length - 1] : null;
    if (prev && prev.speaker === speaker && Number(inicio) - Number(prev.fim) < MERGE_GAP_MS && prev.text.length < 900) {
      prev.text = (prev.text + ' ' + clean).replace(/\s+/g, ' ').trim();
      prev.fim = Math.max(Number(prev.fim), Number(fim));
      prev.dirty = true;
    } else {
      candidate.ordem = nextOrdem;
      candidate.dirty = true;
      nextOrdem += 1;
      lines.push(candidate);
      if (lines.length > 400) lines.splice(0, lines.length - 400);
    }
    persistDirty();
    renderLines();
    refreshMessage();
    saveLines();
  }

  async function saveLines() {
    if (saving || !reuniao) return;
    saving = true;
    try {
      if (!(await ensureKey())) {
        setMessage('Abra o Planeje neste Chrome para continuar gravando. Nada se perde.', false);
        return;
      }
      if (!reuniao.started) {
        await callFunction('status', { status: 'em_andamento' });
        reuniao.started = true;
      }
      var dirty = lines.filter(function (line) { return line.dirty; });
      for (var i = 0; i < dirty.length; i += 1) {
        var line = dirty[i];
        var sent = line.text;
        await callFunction('fala', {
          ordem: line.ordem,
          nome: line.speaker,
          texto: sent,
          inicio_em: new Date(line.inicio).toISOString(),
          fim_em: new Date(line.fim).toISOString(),
        });
        line.saved = true;
        if (line.text === sent) line.dirty = false;
      }
      persistDirty();
      if (!finishing) setMessage('Gravando · ' + (reuniao.empresa || reuniao.titulo || 'cliente'), false);
    } catch (error) {
      setMessage('Sem conexão para gravar agora. Tento de novo sozinho.', false);
    } finally {
      saving = false;
      refreshMessage();
    }
  }

  function pushSlot(source, blob, inicio, fim, speaker) {
    if (!reuniao || stopped) return;
    slots.push({ seq: slotSeq, source: source, blob: blob, inicio: inicio, fim: fim, speaker: speaker, status: 'waiting', tries: 0, nextTry: 0, doneAt: 0, text: '' });
    slotSeq += 1;
    slots.sort(function (a, b) { return a.inicio - b.inicio; });
    renderLines();
    refreshMessage();
    pump();
  }

  function pump() {
    if (!reuniao) return;
    var now = Date.now();
    for (var i = 0; i < slots.length && running < MAX_PARALLEL; i += 1) {
      var slot = slots[i];
      if (slot.status !== 'waiting' || slot.nextTry > now) continue;
      transcribeSlot(slot);
    }
  }

  async function transcribeSlot(slot) {
    slot.status = 'running';
    running += 1;
    try {
      if (!(await ensureKey())) throw new Error('sem chave');
      var form = new FormData();
      form.append('file', slot.blob, slot.source === 'mic' ? 'eu.wav' : 'sala.webm');
      var data = await callFunction('transcrever', form, true);
      slot.text = data && data.text ? String(data.text) : '';
      slot.status = 'done';
      slot.doneAt = Date.now();
      slot.blob = null;
    } catch (error) {
      slot.tries += 1;
      slot.status = 'waiting';
      slot.nextTry = Date.now() + Math.min(20000, 1500 * Math.pow(2, Math.min(slot.tries, 4)));
      if (error && error.message === 'sem chave') setMessage('Abra o Planeje neste Chrome para continuar gravando. Nada se perde.', false);
    } finally {
      running -= 1;
      drain();
      pump();
    }
  }

  function drain() {
    var now = Date.now();
    var changed = false;
    while (slots.length) {
      var first = slots[0];
      if (first.status !== 'done') {
        var later = slots.slice(1).find(function (slot) { return slot.status === 'done' && now - slot.doneAt > HEAD_WAIT_MS; });
        if (!later) break;
        slots.splice(slots.indexOf(later), 1);
        commitSlot(later);
        changed = true;
        continue;
      }
      slots.shift();
      commitSlot(first);
      changed = true;
    }
    if (changed || !slots.length) {
      renderLines();
      refreshMessage();
    }
  }

  function commitSlot(slot) {
    if (slot.source === 'mic' && slot.text && api.wordOverlap(slot.text, liveOtherCaption(slot.inicio, slot.fim)) >= 0.6) return;
    var speaker = slot.source === 'mic' ? (slot.speaker || myName()) : remoteSpeakerFor(slot.inicio, slot.fim);
    addText(slot.source, speaker, slot.text, slot.inicio, slot.fim);
  }

  var mic = { stream: null, ctx: null, node: null, rate: 16000, pre: [], phrase: [], talking: false, silence: 0, voiced: 0, noise: 0.004, startedAt: 0, opening: false };

  function frameLevel(buf) {
    var sum = 0;
    for (var i = 0; i < buf.length; i += 1) sum += buf[i] * buf[i];
    return Math.sqrt(sum / Math.max(1, buf.length));
  }

  function countSamples(chunks) {
    var n = 0;
    for (var i = 0; i < chunks.length; i += 1) n += chunks[i].length;
    return n;
  }

  function encodeWav(chunks, rate) {
    var length = countSamples(chunks);
    var buffer = new ArrayBuffer(44 + length * 2);
    var view = new DataView(buffer);
    function put(offset, str) {
      for (var n = 0; n < str.length; n += 1) view.setUint8(offset + n, str.charCodeAt(n));
    }
    put(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    put(8, 'WAVE');
    put(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, rate, true);
    view.setUint32(28, rate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    put(36, 'data');
    view.setUint32(40, length * 2, true);
    var offset = 44;
    for (var i = 0; i < chunks.length; i += 1) {
      for (var j = 0; j < chunks[i].length; j += 1) {
        var s = Math.max(-1, Math.min(1, chunks[i][j]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
        offset += 2;
      }
    }
    return new Blob([buffer], { type: 'audio/wav' });
  }

  function flushMic() {
    if (!mic.phrase.length) return;
    var chunks = mic.phrase;
    var voicedSec = mic.voiced / mic.rate;
    var inicio = mic.startedAt || Date.now();
    mic.phrase = [];
    mic.talking = false;
    mic.silence = 0;
    mic.voiced = 0;
    mic.startedAt = 0;
    livePreview = null;
    if (voicedSec < 0.5) {
      renderLines();
      return;
    }
    pushSlot('mic', encodeWav(chunks, mic.rate), inicio, Date.now(), myName());
  }

  function onMicFrame(event) {
    if (stopped || !reuniao) return;
    var input = event.inputBuffer.getChannelData(0);
    var copy = new Float32Array(input.length);
    copy.set(input);
    var level = frameLevel(copy);
    var gate = Math.max(0.01, mic.noise * 3.5);
    if (!mic.talking) {
      mic.pre.push(copy);
      while (countSamples(mic.pre) > mic.rate * 0.6) mic.pre.shift();
      if (level < gate) {
        mic.noise = mic.noise * 0.97 + level * 0.03;
        return;
      }
      mic.talking = true;
      mic.startedAt = Date.now() - Math.round((countSamples(mic.pre) / mic.rate) * 1000);
      mic.phrase = mic.pre.slice();
      mic.pre = [];
      mic.silence = 0;
      mic.voiced = copy.length;
      mic.phrase.push(copy);
      livePreview = { speaker: myName() };
      renderLines();
      return;
    }
    mic.phrase.push(copy);
    if (level >= gate * 0.6) {
      mic.silence = 0;
      mic.voiced += copy.length;
    } else {
      mic.silence += copy.length;
    }
    var total = countSamples(mic.phrase);
    if (mic.silence >= mic.rate * 0.9 || total >= mic.rate * 28) flushMic();
  }

  function meetMicMuted() {
    var marked = document.querySelectorAll('[data-is-muted][aria-label]');
    for (var i = 0; i < marked.length; i += 1) {
      if (/microfone|microphone/i.test(marked[i].getAttribute('aria-label') || '')) return marked[i].getAttribute('data-is-muted') === 'true';
    }
    var buttons = document.querySelectorAll('button[aria-label], [role="button"][aria-label]');
    for (var j = 0; j < buttons.length; j += 1) {
      var label = buttons[j].getAttribute('aria-label') || '';
      if (!/microfone|microphone/i.test(label) || bar.contains(buttons[j])) continue;
      if (/^(ativar|turn on|unmute)/i.test(label)) return true;
      if (/^(desativar|turn off|mute)/i.test(label)) return false;
    }
    return false;
  }

  function watchMute() {
    var muted = meetMicMuted();
    if (muted === micMuted) return;
    micMuted = muted;
    if (muted) stopMic();
    else startMic();
    renderLines();
  }

  function startMic() {
    if (stopped || micMuted) return;
    if (mic.ctx && mic.ctx.state === 'suspended') mic.ctx.resume();
    if (mic.stream || mic.opening) return;
    mic.opening = true;
    navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
    }).then(function (stream) {
      mic.opening = false;
      if (stopped) {
        stream.getTracks().forEach(function (track) { track.stop(); });
        return;
      }
      mic.stream = stream;
      var Ctx = window.AudioContext || window.webkitAudioContext;
      try { mic.ctx = new Ctx({ sampleRate: 16000 }); } catch (error) { mic.ctx = new Ctx(); }
      mic.rate = mic.ctx.sampleRate || 16000;
      var source = mic.ctx.createMediaStreamSource(stream);
      mic.node = mic.ctx.createScriptProcessor(4096, 1, 1);
      mic.node.onaudioprocess = onMicFrame;
      var mute = mic.ctx.createGain();
      mute.gain.value = 0;
      source.connect(mic.node);
      mic.node.connect(mute);
      mute.connect(mic.ctx.destination);
      if (mic.ctx.state === 'suspended') mic.ctx.resume();
    }).catch(function () {
      mic.opening = false;
      setMessage('O Chrome não liberou o microfone. Clique no cadeado da barra e permita.', false);
    });
  }

  function stopMic() {
    flushMic();
    if (mic.node) {
      mic.node.onaudioprocess = null;
      try { mic.node.disconnect(); } catch (error) { /* já solto */ }
      mic.node = null;
    }
    if (mic.stream) {
      mic.stream.getTracks().forEach(function (track) { track.stop(); });
      mic.stream = null;
    }
    if (mic.ctx) {
      mic.ctx.close().catch(function () {});
      mic.ctx = null;
    }
    mic.pre = [];
    mic.talking = false;
    mic.opening = false;
    livePreview = null;
  }

  function askRoomAudio() {
    if (roomAudioOn || stopped) return;
    try {
      chrome.runtime.sendMessage({ type: 'ouvir-sala' }, function (res) {
        if (chrome.runtime.lastError) return;
        if (res && res.ok) roomAudioOn = true;
      });
    } catch (error) { /* sem áudio da aba */ }
  }

  function stopRoomAudio() {
    roomAudioOn = false;
    try {
      chrome.runtime.sendMessage({ type: 'parar-audio' }, function () { void chrome.runtime.lastError; });
    } catch (error) { /* extensão recarregando */ }
  }

  function b64ToBlob(b64, type) {
    var bin = atob(b64);
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: type || 'audio/webm' });
  }

  async function restorePending() {
    var key = 'planejeFalasPendentes:' + reuniao.id;
    var stored = await storageGet([key]);
    var pending = stored[key] || [];
    pending.forEach(function (item) {
      if (item.ordem >= nextOrdem) nextOrdem = item.ordem + 1;
      lines.push({ ordem: item.ordem, speaker: item.speaker, text: item.text, inicio: item.inicio, fim: item.fim, source: item.source, dirty: true });
    });
    lines.sort(function (a, b) { return a.ordem - b.ordem; });
  }

  async function attach(code) {
    var token = await sessionToken();
    if (!token) {
      setMessage('Abra o Planeje e entre na sua conta neste Chrome.', true);
      return;
    }
    var select = 'cliente_reunioes?meet_code=eq.' + encodeURIComponent(code) + '&select=id,titulo,status,iniciada_em,cliente_id,clientes(empresa)';
    var found = await rest(token, select, { method: 'GET' });
    var row = Array.isArray(found) ? found[0] : null;
    if (!row) {
      var stored = await storageGet(['planejeReuniaoPendente']);
      var pending = stored.planejeReuniaoPendente;
      if (pending && pending.id && Date.now() - Number(pending.at || 0) < 3 * 60 * 60 * 1000) {
        try {
          await rest(token, 'rpc/vincular_cliente_reuniao_meet', {
            method: 'POST',
            body: { p_id: pending.id, p_code: code },
            headers: { Prefer: 'return=representation' },
          });
          found = await rest(token, select, { method: 'GET' });
          row = Array.isArray(found) ? found[0] : null;
        } catch (error) {
          row = null;
        }
      }
    }
    if (!row) {
      setMessage('Esta sala não está numa reunião de cliente. Crie na ficha e cole o link, ou use Criar e abrir sala.', true);
      return;
    }
    reuniao = { id: row.id, titulo: row.titulo, empresa: row.clientes && row.clientes.empresa, started: row.status === 'em_andamento', chave: '', chaveExp: 0, planejeName: '' };
    var last = await rest(token, 'cliente_reuniao_falas?reuniao_id=eq.' + row.id + '&select=ordem&order=ordem.desc&limit=1', { method: 'GET' });
    nextOrdem = last && last[0] ? Number(last[0].ordem) + 1 : 0;
    await restorePending();
    if (!(await ensureKey())) {
      setMessage('Não consegui liberar a gravação. Recarregue o Planeje e esta aba.', true);
      reuniao = null;
      return;
    }
    stopped = false;
    finishing = false;
    setMessage('Gravando · ' + (reuniao.empresa || reuniao.titulo), false);
    renderLines();
    attachedAt = Date.now();
    startMic();
    ensureCaptions();
    saveLines();
  }

  function resetRoom() {
    stopped = true;
    stopMic();
    stopRoomAudio();
    reuniao = null;
    lines = [];
    slots = [];
    speakerLog = [];
    capStates = [];
    recentCaptions = [];
    livePreview = null;
    renderLines();
  }

  function watchLocation() {
    var code = api.parseMeetCode(location.href);
    if (code === lastCode || finishing) return;
    lastCode = code;
    resetRoom();
    if (!code) {
      setMessage('Abra a sala. O link entra na reunião que você acabou de criar.', true);
      return;
    }
    setMessage('Ligando esta sala ao cliente…', true);
    attach(code).catch(function (error) {
      setMessage(error.message || 'Não achei a reunião.', true);
    });
  }

  stopButton.addEventListener('click', async function () {
    if (!reuniao || finishing) return;
    finishing = true;
    readCaptions(true);
    stopMic();
    stopRoomAudio();
    stopped = true;
    setMessage('Finalizando a transcrição…', false);
    var deadline = Date.now() + 90000;
    while (Date.now() < deadline && (slots.length || running)) {
      slots.forEach(function (slot) { if (slot.status === 'waiting') slot.nextTry = 0; });
      pump();
      drain();
      await wait(500);
    }
    slots.forEach(function (slot) { if (slot.status === 'done') commitSlot(slot); });
    slots = [];
    for (var i = 0; i < 10 && lines.some(function (line) { return line.dirty; }); i += 1) {
      await saveLines();
      if (lines.some(function (line) { return line.dirty; })) await wait(1500);
    }
    try {
      await callFunction('status', { status: 'transcrita' });
      var left = lines.filter(function (line) { return line.dirty; }).length;
      setMessage(left ? 'Encerrada. ' + left + ' fala(s) ainda serão gravadas quando voltar a conexão.' : 'Transcrição salva na ficha do cliente.', true);
    } catch (error) {
      setMessage('A transcrição ficou salva, mas não marquei como encerrada.', true);
    }
    finishing = false;
    reuniao = lines.some(function (line) { return line.dirty; }) ? reuniao : null;
    renderLines();
  });

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (!msg || msg.type !== 'audio-sala') {
      sendResponse({ ok: false });
      return;
    }
    if (reuniao && !stopped && msg.b64 && !captionRegion()) {
      pushSlot('sala', b64ToBlob(msg.b64, msg.mime), Number(msg.inicio) || Date.now(), Number(msg.fim) || Date.now(), '');
    }
    sendResponse({ ok: true });
  });

  setInterval(watchLocation, 700);
  watchLocation();

  setInterval(function () {
    if (!reuniao || stopped) return;
    noteSpeaker();
    watchMute();
  }, 250);

  setInterval(function () {
    if (!reuniao || stopped) return;
    readCaptions(false);
  }, 300);

  setInterval(function () {
    if (!reuniao) return;
    pump();
    drain();
    if (lines.some(function (line) { return line.dirty; })) saveLines();
    if (!stopped) {
      if (!mic.stream) startMic();
      if (captionRegion()) {
        if (roomAudioOn) stopRoomAudio();
      } else {
        ensureCaptions();
        if (!roomAudioOn && Date.now() - attachedAt > 20000) askRoomAudio();
      }
    }
  }, 3000);

  window.addEventListener('pointerdown', function () {
    if (reuniao && !stopped) startMic();
  }, true);
})();
