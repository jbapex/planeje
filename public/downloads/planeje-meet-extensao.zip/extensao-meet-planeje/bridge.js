(function bridge() {
  var SESSION_KEY = 'sb-planeje-auth-token';

  function readSession() {
    try {
      var raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      var data = JSON.parse(raw);
      var session = data && data.currentSession ? data.currentSession : data;
      var token = session && session.access_token;
      if (!token) return null;
      return { access_token: token, expires_at: session.expires_at || 0 };
    } catch (error) {
      return null;
    }
  }

  function readPending() {
    try {
      return JSON.parse(localStorage.getItem('planeje-reuniao-pendente') || 'null');
    } catch (error) {
      return null;
    }
  }

  function sync() {
    if (!chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.set({
      planejeSession: readSession(),
      planejeReuniaoPendente: readPending(),
    });
  }

  sync();
  setInterval(sync, 1500);
  window.addEventListener('planeje-reuniao-pendente', sync);
  window.addEventListener('storage', sync);
})();
