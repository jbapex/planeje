# Planeje no Chrome

Ícone **P** flutuante em **qualquer página** do navegador (sites http/https). Arraste para o lado que quiser; clique para expandir o painel com as demandas/tarefas do dia. Também cria rápido uma **tarefa** (`/#/tasks`) ou uma **demanda** para o gestor (`/#/requests`).

## Instalar

No Planeje: `/#/extensao-whatsapp` (Configurações → WhatsApp → Extensão no Chrome). Baixe o ZIP e siga os passos da página.

Ou, a partir desta pasta:

1. Abra `chrome://extensions`
2. Ative **Modo do desenvolvedor**
3. Clique em **Carregar sem compactação**
4. Escolha esta pasta: `extensao-whatsapp-planeje`
5. Recarregue qualquer aba aberta. O ícone **P** aparece no canto da página (não entra em `chrome://` nem na Chrome Web Store).

No site, o **ícone P** arrasta para qualquer lugar. Clique para expandir o painel na própria tela; use **–** para recolher. No WhatsApp Web, o nome do chat e o texto marcado ainda entram no formulário.

A extensão avisa com popup (e um recado na tela) quando uma tarefa muda de etapa, chega mensagem nas Conversas ou um **grupo fica sem resposta** (IA do Planeje + lista do WhatsApp Web). Mensagem da equipe da agência (Gabriel, Jheimison, Rayane, Poliana, Raphael, Josias) não conta como “sem resposta”.

Na aba **Hoje**, use **Tarefas** / **Grupos** para separar as listas; em **Tudo**, clique no título dos grupos para recolher essa parte.

Alertas de mensagem e grupos usam só os canais da agência (JB APEX — Raphael e Poliana), não números de clientes.

Criar tarefa/demanda exige cliente operacional (não JB APEX), mantém o que você digitou ao trocar o tipo e abre o item certo no Planeje.

## Login

Use o mesmo e-mail e senha do Planeje. A extensão fala com o mesmo Supabase do app, então as permissões (RLS) são as da sua conta.

## Como usar

- Aba **Hoje**: tarefas com entrega hoje/atrasadas e solicitações abertas, agrupadas por responsável. Filtro por pessoa ou “Só eu”.
- Aba **Criar rápido**:
  - **Tarefa** — cai na página de tarefas
  - **Demanda para o gestor** — cai em Solicitações, com responsável no gestor escolhido
- O nome do chat aberto e o texto que você marcar no WhatsApp preenchem o formulário.
- Em **Ajustes** você pode trocar a URL do Planeje (padrão `https://planeje.jbapex.com.br`).

## Requisitos

Chrome 114+ (API de Side Panel).
