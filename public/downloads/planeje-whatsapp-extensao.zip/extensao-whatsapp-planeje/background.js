import { getSession, getProfile, loadPrefs, pollAlerts, mergeGruposSemResposta } from './lib/api.js';

const ALARM = 'planeje-alerts';
let cachedPrefs = { openMode: 'button', showFab: true, notifyChanges: true };

function panelUrl() {
  return chrome.runtime.getURL('sidepanel.html');
}

function openPopupWindow() {
  chrome.windows.create({
    url: panelUrl(),
    type: 'popup',
    width: 420,
    height: 760,
    focused: true,
  });
}

function expandOnTab(tabId, fallback = true) {
  if (!tabId) {
    if (fallback) openPopupWindow();
    return;
  }
  chrome.tabs.sendMessage(tabId, { type: 'EXPAND_WIDGET' }, () => {
    if (chrome.runtime.lastError && fallback) openPopupWindow();
  });
}

function openUi(tabId) {
  if (tabId) {
    expandOnTab(tabId);
    return;
  }
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    expandOnTab(tabs[0]?.id);
  });
}

function broadcastToPages(message) {
  chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }, (tabs) => {
    for (const tab of tabs || []) {
      if (!tab.id) continue;
      chrome.tabs.sendMessage(tab.id, message, () => void chrome.runtime.lastError);
    }
  });
}

async function refreshPrefs() {
  try {
    cachedPrefs = await loadPrefs();
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  } catch {
    cachedPrefs = cachedPrefs || { openMode: 'button' };
  }
}

async function ensureAlarm() {
  try {
    const alarm = await chrome.alarms.get(ALARM);
    if (!alarm) await chrome.alarms.create(ALARM, { periodInMinutes: 1 });
  } catch {
    /* permissão ainda não concedida */
  }
}

async function runAlertPoll() {
  try {
    if (cachedPrefs.notifyChanges === false) return;
    const session = await getSession();
    const profile = session ? await getProfile() : null;
    if (!session || !profile) return;

    const stored = await chrome.storage.local.get(['alertCursor', 'waGruposLive']);
    const { events, cursor, grupos } = await pollAlerts(session, profile, stored.alertCursor || {});
    const knownNames = new Set((grupos || []).map((g) => String(g.name || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim()).filter(Boolean));
    const live = (stored.waGruposLive?.groups || []).filter((group) => {
      if (!knownNames.size) return false;
      const key = String(group.name || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
      return knownNames.has(key);
    });
    const merged = mergeGruposSemResposta(grupos || [], live);
    await chrome.storage.local.set({
      alertCursor: cursor,
      gruposSemResposta: merged,
      agencyGroupNames: [...knownNames],
    });

    const extra = [];
    if (cachedPrefs.alertGrupos !== false) {
      const notified = { ...(stored.alertCursor?.grupoNotified || {}) };
      const now = Date.now();
      for (const group of live) {
        const last = notified[group.id] || 0;
        if (now - last < 15 * 60 * 1000) continue;
        extra.push({
          type: 'grupo',
          id: `wa-grupo:${group.id}:${now}`,
          title: 'Grupo sem resposta',
          body: `${group.name}: ${group.reason || 'alguém espera resposta'}`,
        });
        notified[group.id] = now;
      }
      cursor.grupoNotified = notified;
      await chrome.storage.local.set({ alertCursor: cursor });
    }

    const allEvents = cachedPrefs.alertGrupos === false ? events.filter((e) => e.type !== 'grupo') : [...events, ...extra];
    if (!allEvents.length && !merged.length) return;

    for (const event of allEvents) {
      chrome.notifications.create(event.id, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: event.title,
        message: event.body,
        priority: 2,
      });
    }

    broadcastToPages({
      type: 'PLANEJE_TOAST',
      events: allEvents,
      badge: merged.length || allEvents.length,
      grupos: merged,
    });
  } catch {
    /* não derruba o worker */
  }
}

refreshPrefs();
ensureAlarm();

chrome.runtime.onInstalled.addListener(() => {
  refreshPrefs();
  ensureAlarm();
});
chrome.runtime.onStartup.addListener(() => {
  refreshPrefs();
  ensureAlarm();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) runAlertPoll();
});

chrome.notifications.onClicked.addListener((id) => {
  chrome.notifications.clear(id);
  openUi();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'OPEN_TAB' && message.url) {
    chrome.tabs.create({ url: message.url });
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'OPEN_SIDEPANEL' || message?.type === 'OPEN_UI') {
    openUi(sender.tab?.id);
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'WA_GRUPOS_UPDATE') {
    const groups = message.groups || [];
    chrome.storage.local.get(['gruposSemResposta', 'agencyGroupNames'], (stored) => {
      const allowed = new Set(
        [
          ...(stored.agencyGroupNames || []),
          ...(stored.gruposSemResposta || []).map((g) => g.name),
        ]
          .map((name) =>
            String(name || '')
              .normalize('NFD')
              .replace(/[\u0300-\u036f]/g, '')
              .toLowerCase()
              .trim()
          )
          .filter(Boolean)
      );
      const scoped = allowed.size
        ? groups.filter((group) =>
            allowed.has(
              String(group.name || '')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .toLowerCase()
                .trim()
            )
          )
        : [];
      const merged = mergeGruposSemResposta(stored.gruposSemResposta || [], scoped);
      chrome.storage.local.set({ waGruposLive: { at: Date.now(), groups: scoped }, gruposSemResposta: merged });
      chrome.runtime.sendMessage({ type: 'GRUPOS_PUSH', grupos: merged }).catch(() => {});
      broadcastToPages({ type: 'PLANEJE_TOAST', events: [], badge: merged.length, grupos: merged });
    });
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'FOCUS_WA_CHAT' && message.name) {
    chrome.tabs.query({ url: 'https://web.whatsapp.com/*' }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.update(tabs[0].id, { active: true });
        chrome.tabs.sendMessage(tabs[0].id, { type: 'FOCUS_WA_CHAT', name: message.name }, () => void chrome.runtime.lastError);
      } else {
        chrome.tabs.create({ url: 'https://web.whatsapp.com' });
      }
    });
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'WA_CONTEXT') {
    chrome.storage.local.set({ waContext: message.payload || {} });
    chrome.runtime.sendMessage({ type: 'WA_CONTEXT_PUSH', payload: message.payload || {} }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'PREFS_CHANGED') {
    cachedPrefs = { ...cachedPrefs, ...(message.prefs || {}) };
    refreshPrefs();
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'SESSION_CHANGED') {
    chrome.storage.local.remove('alertCursor');
    runAlertPoll();
    sendResponse({ ok: true });
    return false;
  }

  return false;
});
