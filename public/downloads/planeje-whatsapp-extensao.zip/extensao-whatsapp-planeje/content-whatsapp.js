(() => {
  import(chrome.runtime.getURL('widget.js')).catch((err) => {
    console.error('Planeje widget:', err);
  });

  if (location.hostname === 'web.whatsapp.com') {
    import(chrome.runtime.getURL('lib/waGruposScan.js'))
      .then((mod) => mod.startWhatsAppGroupWatch())
      .catch((err) => console.error('Planeje grupos:', err));
  }

  function currentContext() {
    const header = document.querySelector('#main header');
    const titled = header?.querySelector('span[dir="auto"][title]') || header?.querySelector('span[title]');
    return {
      chatName: (titled?.getAttribute('title') || titled?.textContent || '').trim(),
      selectedText: (window.getSelection?.()?.toString()?.trim() || '').slice(0, 2000),
      at: Date.now(),
    };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const api = document.getElementById('planeje-wa-dock')?.__planeje;
    if (message?.type === 'GET_WA_CONTEXT') {
      const payload = currentContext();
      chrome.runtime.sendMessage({ type: 'WA_CONTEXT', payload }, () => void chrome.runtime.lastError);
      sendResponse(payload);
      return true;
    }
    if (message?.type === 'TOGGLE_OVERLAY' || message?.type === 'OPEN_UI' || message?.type === 'EXPAND_WIDGET') {
      api?.expand?.();
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === 'PLANEJE_TOAST') {
      if (message.events?.length) api?.toast?.(message.events);
      api?.setBadge?.(message.badge || 0);
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === 'FOCUS_WA_CHAT' && message.name) {
      import(chrome.runtime.getURL('lib/waGruposScan.js'))
        .then((mod) => sendResponse({ ok: mod.focusWhatsAppChat(message.name) }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    return false;
  });
})();
