import { mountPlanejeApp } from './sidepanel.js';

const HOST_ID = 'planeje-wa-dock';
const POS_KEY = 'widgetPos';
const ICON = 36;
const DRAG_THRESHOLD = 6;
const MARGIN = 8;

function expandedSize() {
  return {
    w: Math.min(480, Math.max(360, window.innerWidth - MARGIN * 2)),
    h: Math.max(280, window.innerHeight - MARGIN * 2),
  };
}

function clamp(left, top, width, height) {
  const maxL = Math.max(MARGIN, window.innerWidth - width - MARGIN);
  const maxT = Math.max(MARGIN, window.innerHeight - height - MARGIN);
  return {
    left: Math.min(maxL, Math.max(MARGIN, left)),
    top: Math.min(maxT, Math.max(MARGIN, top)),
  };
}

function defaultPos() {
  const { w, h } = expandedSize();
  return { left: window.innerWidth - ICON - 20, top: window.innerHeight - ICON - 24, expanded: false, w, h };
}

async function loadPos() {
  const stored = await chrome.storage.local.get([POS_KEY]);
  return { ...defaultPos(), ...(stored[POS_KEY] || {}) };
}

function savePos(pos) {
  chrome.storage.local.set({ [POS_KEY]: pos });
}

function readChatName() {
  const header = document.querySelector('#main header');
  if (!header) return '';
  const titled = header.querySelector('span[dir="auto"][title]') || header.querySelector('span[title]');
  return (titled?.getAttribute('title') || titled?.textContent || '').trim();
}

export function mountWidget() {
  if (document.getElementById(HOST_ID)) return document.getElementById(HOST_ID);
  if (!document.body) return null;

  const host = document.createElement('div');
  host.id = HOST_ID;
  const shadow = host.attachShadow({ mode: 'open' });

  const widgetStyle = document.createElement('link');
  widgetStyle.rel = 'stylesheet';
  widgetStyle.href = chrome.runtime.getURL('widget.css');
  const panelStyle = document.createElement('link');
  panelStyle.rel = 'stylesheet';
  panelStyle.href = chrome.runtime.getURL('sidepanel.css');
  shadow.append(widgetStyle, panelStyle);

  const wrap = document.createElement('div');
  wrap.className = 'dock';
  wrap.innerHTML = `
    <button type="button" class="icon" title="Arraste ou clique para abrir o Planeje" aria-label="Planeje">
      <span>P</span>
      <span class="badge" hidden></span>
    </button>
    <div class="panel">
      <div class="handle">
        <strong>Planeje</strong>
        <div class="handle-actions">
          <button type="button" class="collapse" title="Recolher" aria-label="Recolher">–</button>
        </div>
      </div>
      <div class="body planeje-root">
        <div class="planeje-app" id="planeje-ext-app">Carregando…</div>
      </div>
    </div>
    <div class="toast" hidden></div>
  `;
  shadow.append(wrap);
  document.body.appendChild(host);

  const icon = wrap.querySelector('.icon');
  const collapseBtn = wrap.querySelector('.collapse');
  const handle = wrap.querySelector('.handle');
  const appEl = wrap.querySelector('#planeje-ext-app');
  const toastEl = wrap.querySelector('.toast');
  const badgeEl = wrap.querySelector('.badge');

  let pos = defaultPos();
  let mounted = false;
  let drag = null;

  function applyPos() {
    const size = pos.expanded ? expandedSize() : { w: ICON, h: ICON };
    pos = { ...pos, ...size };
    const next = clamp(pos.left, pos.top, size.w, size.h);
    pos.left = next.left;
    pos.top = next.top;
    host.style.left = `${pos.left}px`;
    host.style.top = `${pos.top}px`;
    host.style.width = `${size.w}px`;
    host.style.height = `${size.h}px`;
    wrap.style.setProperty('--pw', `${size.w}px`);
    wrap.style.setProperty('--ph', `${size.h}px`);
    wrap.classList.toggle('expanded', pos.expanded);
  }

  function expand() {
    const size = expandedSize();
    if (!pos.expanded) {
      pos.iconLeft = pos.left;
      pos.iconTop = pos.top;
      pos.left = Math.min(pos.left, window.innerWidth - size.w - MARGIN);
      pos.top = MARGIN;
    }
    pos.expanded = true;
    applyPos();
    savePos(pos);
    if (!mounted) {
      mounted = true;
      try {
        if (!appEl) throw new Error('Área do painel não encontrada.');
        mountPlanejeApp(appEl);
      } catch (err) {
        mounted = false;
        console.error('Planeje mount:', err);
        if (appEl) {
          appEl.textContent = err.message || 'Não foi possível abrir o Planeje.';
        }
      }
    }
    chrome.storage.local.set({
      waContext: {
        chatName: readChatName(),
        selectedText: (window.getSelection?.()?.toString()?.trim() || '').slice(0, 2000),
        at: Date.now(),
      },
    });
  }

  function collapse() {
    pos.expanded = false;
    if (Number.isFinite(pos.iconLeft)) pos.left = pos.iconLeft;
    if (Number.isFinite(pos.iconTop)) pos.top = pos.iconTop;
    applyPos();
    savePos(pos);
  }

  function toggle() {
    if (pos.expanded) collapse();
    else expand();
  }

  function startDrag(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    drag = {
      startX: event.clientX,
      startY: event.clientY,
      left: pos.left,
      top: pos.top,
      moved: false,
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp, { once: true });
  }

  function onMove(event) {
    if (!drag) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) drag.moved = true;
    if (!drag.moved) return;
    const size = pos.expanded ? expandedSize() : { w: ICON, h: ICON };
    const next = clamp(drag.left + dx, drag.top + dy, size.w, size.h);
    pos.left = next.left;
    pos.top = next.top;
    host.style.left = `${pos.left}px`;
    host.style.top = `${pos.top}px`;
  }

  function onUp() {
    window.removeEventListener('pointermove', onMove);
    const wasDrag = drag?.moved;
    drag = null;
    if (wasDrag) {
      if (pos.expanded) pos.iconLeft = pos.left;
      savePos(pos);
      return;
    }
    if (!pos.expanded) expand();
  }

  icon.addEventListener('pointerdown', startDrag);
  handle.addEventListener('pointerdown', (event) => {
    if (event.target.closest('button')) return;
    startDrag(event);
  });
  collapseBtn.addEventListener('click', (event) => {
    event.preventDefault();
    collapse();
  });

  toastEl.addEventListener('click', () => {
    toastEl.classList.remove('show');
    expand();
  });

  host.__planeje = {
    expand,
    collapse,
    toggle,
    setBadge(count) {
      if (!count) {
        badgeEl.hidden = true;
        icon.classList.remove('has-alert');
        return;
      }
      badgeEl.hidden = false;
      badgeEl.textContent = count > 9 ? '9+' : String(count);
      icon.classList.add('has-alert');
    },
    toast(events) {
      if (!events?.length) return;
      toastEl.hidden = false;
      toastEl.replaceChildren();
      const title = document.createElement('strong');
      title.textContent = events[0].title || 'Planeje';
      const body = document.createElement('span');
      body.textContent = events[0].body || '';
      toastEl.append(title, body);
      toastEl.classList.add('show');
      clearTimeout(host.__toastTimer);
      host.__toastTimer = setTimeout(() => toastEl.classList.remove('show'), 7000);
    },
  };

  loadPos().then((saved) => {
    pos = { ...defaultPos(), ...saved, expanded: false };
    applyPos();
  });
  chrome.storage.local.get(['gruposSemResposta'], (stored) => {
    host.__planeje.setBadge((stored.gruposSemResposta || []).length);
  });

  window.addEventListener('resize', () => applyPos());
  return host;
}

export function getWidget() {
  return document.getElementById(HOST_ID);
}

if (document.body) mountWidget();
else document.addEventListener('DOMContentLoaded', mountWidget);
setInterval(() => {
  if (!document.getElementById(HOST_ID) && document.body) mountWidget();
}, 2500);
