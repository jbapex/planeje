import * as api from './lib/api.js';
import { storageGet } from './lib/storage.js';

let root = null;

function asset(path) {
  return globalThis.chrome?.runtime?.getURL?.(path) || path;
}

const state = {
  view: 'hoje',
  kind: 'tarefa',
  session: null,
  profile: null,
  wa: { chatName: '', selectedText: '' },
  lookups: { clients: [], people: [], statuses: [] },
  hoje: { day: api.todayISO(), tarefas: [], demandas: [] },
  grupos: [],
  personFilter: 'all',
  loading: true,
  saving: false,
  error: '',
  notice: '',
  settingsOpen: false,
  prefs: { ...api.DEFAULT_PREFS },
  form: blankForm(),
};

function blankForm() {
  return {
    title: '',
    description: '',
    client_id: '',
    assignee_id: '',
    gestor_id: '',
    due_date: api.todayISO(),
    prazo: api.todayISO(),
    type: 'arte',
    priority_task: 'medium',
    priority_demanda: 'media',
    conversation_id: '',
    whatsapp_chat_jid: '',
  };
}

const DEMANDA_STATUS_LABEL = {
  aberta: 'Aberta',
  analise: 'Em análise',
  execucao: 'Em execução',
  concluida: 'Concluída',
  rejeitada: 'Rejeitada',
};

function demandaStatusLabel(status) {
  const key = String(status || '').toLowerCase();
  return DEMANDA_STATUS_LABEL[key] || status || '—';
}

function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function applyWaToForm() {
  const clients = api.clientsForCreate(state.lookups.clients);
  if (!state.form.title && state.wa.chatName) {
    state.form.title = state.kind === 'demanda' ? `Demanda — ${state.wa.chatName}` : `Pedido — ${state.wa.chatName}`;
  }
  if (!state.form.description && state.wa.selectedText) {
    state.form.description = state.wa.selectedText;
  }
  if (state.form.client_id && !clients.some((c) => c.id === state.form.client_id)) {
    state.form.client_id = '';
  }
  if (!state.form.client_id && state.wa.chatName) {
    const match = api.matchClient(state.wa.chatName, clients);
    if (match) state.form.client_id = match.id;
  }
  if (!state.form.assignee_id && state.profile?.id) state.form.assignee_id = state.profile.id;
  if (!state.form.gestor_id) {
    state.form.gestor_id = api.defaultGestorId(state.lookups.people, state.profile?.id);
  }
  if (!state.form.due_date) state.form.due_date = api.todayISO();
  if (!state.form.prazo) state.form.prazo = api.todayISO();
}

async function refreshAuth() {
  state.session = await api.getSession();
  state.profile = state.session ? await api.getProfile() : null;
}

async function refreshData() {
  if (!state.session) return;
  state.lookups = await api.fetchLookups(state.session);
  state.hoje = await api.fetchHoje(state.session, state.lookups.statuses);
  const live = (await storageGet(['waGruposLive', 'gruposSemResposta'])).waGruposLive?.groups || [];
  const fromApi = await api.fetchGruposSemResposta(state.session).catch(() => []);
  const merged = api.mergeGruposSemResposta(fromApi, live);
  state.grupos = await api.attachGrupoContexto(state.session, merged, state.lookups).catch(() => merged);
  applyWaToForm();
}

function isPreview() {
  return new URLSearchParams(location.search).has('preview');
}

function loadPreview() {
  state.session = { access_token: 'preview', user: { id: 'u1' } };
  state.profile = { id: 'u1', full_name: 'Rafael (preview)', role: 'admin', email: 'rafael@preview' };
  state.lookups = {
    clients: [
      { id: 'c1', empresa: 'Clínica Alpha' },
      { id: 'c2', empresa: 'JB Apex' },
    ],
    people: [
      { id: 'u1', full_name: 'Rafael', role: 'admin' },
      { id: 'u2', full_name: 'Ana', role: 'colaborador' },
    ],
    statuses: [
      { value: 'todo', label: 'A fazer' },
      { value: 'production', label: 'Produção' },
    ],
  };
  state.hoje = {
    day: api.todayISO(),
    tarefas: [
      { id: 't1', title: 'Criativo feriado', status: 'todo', due_date: api.todayISO(), assignee_ids: ['u2'], clientes: { empresa: 'Clínica Alpha' } },
      { id: 't2', title: 'Ajuste de campanha', status: 'production', due_date: '2026-08-30', assignee_ids: ['u1'], clientes: { empresa: 'JB Apex' } },
    ],
    demandas: [
      { id: 'd1', title: 'Pedido de arte no WhatsApp', status: 'aberta', priority: 'alta', origem: 'WhatsApp', owner_id: 'u1', prazo: api.todayISO(), clientes: { empresa: 'Clínica Alpha' } },
    ],
  };
  state.wa = { chatName: 'Clínica Alpha', selectedText: 'Pode criar um criativo para o feriado?' };
  state.grupos = [
    {
      id: 'g1',
      name: 'Clínica Alpha — Equipe',
      preview: 'Maria: Podem confirmar o horário do vídeo?',
      unread: 2,
      source: 'ia',
      reason: 'Cliente aguarda resposta',
      contexto: { kind: 'tarefa_relacionada', label: 'Já tem tarefa: Criativo feriado', relatedType: 'tarefa', relatedId: 't1', relatedTitle: 'Criativo feriado', relatedStatus: 'A fazer' },
    },
  ];
  applyWaToForm();
  state.prefs = { ...api.DEFAULT_PREFS };
  state.loading = false;
}

async function boot() {
  state.loading = true;
  state.error = '';
  render();
  try {
    if (isPreview()) {
      loadPreview();
      return;
    }
    await api.loadConfig();
    state.prefs = await api.loadPrefs();
    await refreshAuth();
    const stored = await storageGet(['waContext', 'waGruposLive', 'gruposSemResposta']);
    if (stored.waContext) state.wa = { ...state.wa, ...stored.waContext };
    if (stored.gruposSemResposta?.length) state.grupos = stored.gruposSemResposta;
    askWhatsAppContext();
    if (state.session) {
      notifyBackground();
      await refreshData();
    }
  } catch (err) {
    state.error = err.message || 'Não foi possível carregar.';
  } finally {
    state.loading = false;
    render();
  }
}

function askWhatsAppContext() {
  if (!globalThis.chrome?.tabs?.query) return;
  try {
    chrome.tabs.query({ url: 'https://web.whatsapp.com/*' }, (tabs) => {
      for (const tab of tabs || []) {
        chrome.tabs.sendMessage(tab.id, { type: 'GET_WA_CONTEXT' }, () => void chrome.runtime.lastError);
      }
    });
  } catch {
    /* content script não tem chrome.tabs */
  }
}

if (globalThis.chrome?.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'WA_CONTEXT_PUSH' && msg.payload) {
      state.wa = { chatName: msg.payload.chatName || '', selectedText: msg.payload.selectedText || '' };
      applyWaToForm();
      render();
    }
    if ((msg?.type === 'GRUPOS_PUSH' || msg?.type === 'PLANEJE_TOAST') && msg.grupos) {
      const merged = api.mergeGruposSemResposta(state.grupos, msg.grupos);
      state.grupos = merged;
      render();
      if (state.session) {
        api.attachGrupoContexto(state.session, merged, state.lookups).then((next) => {
          state.grupos = next;
          render();
        }).catch(() => {});
      }
    }
  });
}

function setView(view) {
  state.view = view;
  state.notice = '';
  state.error = '';
  if (view === 'criar') applyWaToForm();
  render();
}

async function handleLogin(event) {
  event.preventDefault();
  const email = event.target.email.value;
  const password = event.target.password.value;
  state.saving = true;
  state.error = '';
  render();
  try {
    const { session, profile } = await api.signIn(email, password);
    state.session = session;
    state.profile = profile;
    notifyBackground();
    await refreshData();
  } catch (err) {
    state.error = err.message || 'Login inválido.';
  } finally {
    state.saving = false;
    render();
  }
}

async function handleLogout() {
  await api.signOut();
  state.session = null;
  state.profile = null;
  state.form = blankForm();
  notifyBackground();
  render();
}

function notifyBackground() {
  globalThis.chrome?.runtime?.sendMessage?.({ type: 'SESSION_CHANGED' }, () => void chrome.runtime?.lastError);
}

async function handleSaveSettings(event) {
  event.preventDefault();
  await api.saveAppUrl(event.target.appUrl.value);
  state.prefs = await api.savePrefs({
    notifyChanges: event.target.notifyChanges.checked,
    alertGrupos: event.target.alertGrupos.checked,
  });
  state.settingsOpen = false;
  state.notice = 'Ajustes salvos.';
  chrome.runtime?.sendMessage?.({ type: 'PREFS_CHANGED', prefs: state.prefs }, () => void chrome.runtime?.lastError);
  render();
}

async function handleCreate(event) {
  event.preventDefault();
  if (isPreview()) {
    state.notice = 'Preview: no Chrome a tarefa ou demanda seria gravada no Planeje.';
    render();
    return;
  }
  state.saving = true;
  state.error = '';
  state.notice = '';
  const submitBtn = root?.querySelector('#create-form button[type="submit"]');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = 'Salvando…';
  }
  try {
    if (state.kind === 'tarefa') {
      if (!state.form.title.trim() || !state.form.due_date || !state.form.client_id) {
        throw new Error('Preencha título, cliente e data de entrega.');
      }
      const created = await api.createTarefa(state.session, {
        title: state.form.title.trim(),
        description: state.form.description.trim(),
        client_id: state.form.client_id,
        owner_id: state.profile.id,
        assignee_ids: state.form.assignee_id ? [state.form.assignee_id] : [state.profile.id],
        due_date: state.form.due_date,
        type: state.form.type,
        priority: state.form.priority_task || 'medium',
        status: api.initialTaskStatus(state.lookups.statuses),
        whatsapp_chat_name: state.wa.chatName,
        whatsapp_chat_jid: state.form.whatsapp_chat_jid || '',
        atendimento_conversation_id: state.form.conversation_id || '',
      });
      const url = await api.planejeUrl(`/tasks/list/${created.id}`);
      state.notice = `Tarefa criada. Abrindo no Planeje…`;
      state.form = blankForm();
      applyWaToForm();
      openUrl(url);
    } else {
      if (!state.form.title.trim()) {
        throw new Error('Preencha o título da demanda.');
      }
      if (!state.form.client_id) {
        throw new Error('Selecione o cliente da demanda.');
      }
      if (!state.form.gestor_id) {
        throw new Error('Selecione o gestor que vai receber a demanda.');
      }
      const created = await api.createDemanda(state.session, {
        title: state.form.title.trim(),
        description: state.form.description.trim(),
        client_id: state.form.client_id,
        owner_id: state.form.gestor_id,
        prazo: state.form.prazo || api.todayISO(),
        priority: state.form.priority_demanda || 'media',
        whatsapp_chat_name: state.wa.chatName,
      });
      const url = await api.planejeUrl(`/requests?id=${encodeURIComponent(created.id)}`);
      state.notice = 'Demanda enviada para o gestor.';
      state.form = blankForm();
      applyWaToForm();
      openUrl(url);
    }
    await refreshData();
  } catch (err) {
    state.error = err.message || 'Não foi possível salvar.';
  } finally {
    state.saving = false;
    render();
  }
}

function openUrl(url) {
  if (globalThis.chrome?.tabs?.create) {
    chrome.tabs.create({ url });
    return;
  }
  chrome.runtime?.sendMessage?.({ type: 'OPEN_TAB', url }, () => {
    if (chrome.runtime?.lastError) window.open(url, '_blank');
  });
}

function useSelection() {
  if (state.wa.selectedText) {
    state.form.description = state.wa.selectedText;
    render();
  }
}

function renderLogin() {
  root.innerHTML = `
    <section class="login">
      <div class="brand" style="margin-bottom:16px">
        <img class="brand-mark" src="${asset('icons/icon48.png')}" alt="" />
        <div>
          <h1>Planeje no WhatsApp</h1>
          <p>Painel lateral da operação</p>
        </div>
      </div>
      <form class="card" id="login-form">
        <h2>Entrar</h2>
        <p class="muted">Use o mesmo e-mail e senha do Planeje.</p>
        ${state.error ? `<p class="err">${esc(state.error)}</p>` : ''}
        <div class="field">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" required autocomplete="username" />
        </div>
        <div class="field">
          <label for="password">Senha</label>
          <input id="password" name="password" type="password" required autocomplete="current-password" />
        </div>
        <button class="btn" type="submit" ${state.saving ? 'disabled' : ''}>${state.saving ? 'Entrando…' : 'Entrar'}</button>
      </form>
    </section>
  `;
  root.querySelector('#login-form').addEventListener('submit', handleLogin);
}

function filteredHoje() {
  const statuses = state.lookups.statuses || [];
  const pid = state.personFilter;
  const tarefas = state.hoje.tarefas.filter(
    (t) => api.isOpenTask(t, statuses) && (pid === 'all' || api.firstAssignee(t) === pid),
  );
  const demandas = state.hoje.demandas.filter((d) => pid === 'all' || d.owner_id === pid);
  return { tarefas, demandas };
}

function renderItemTask(task) {
  const late = api.isOverdue(task.due_date, state.hoje.day);
  const due = task.due_date === state.hoje.day;
  const client = task.clientes?.empresa || 'Sem cliente';
  return `
    <article class="item" data-open-task="${esc(task.id)}">
      <h3>${esc(task.title)}</h3>
      <div class="meta">
        <span class="pill">${esc(client)}</span>
        <span class="pill">${esc(api.statusLabel(state.lookups.statuses, task.status))}</span>
        ${late ? '<span class="pill late">Atrasada</span>' : due ? '<span class="pill today">Hoje</span>' : ''}
        ${task.due_date ? `<span>${esc(api.formatDayLabel(task.due_date))}</span>` : ''}
      </div>
    </article>
  `;
}

function renderItemDemanda(item) {
  const late = api.isOverdue(item.prazo, state.hoje.day);
  const client = item.clientes?.empresa || 'Sem cliente';
  return `
    <article class="item" data-open-requests="1">
      <h3>${esc(item.title)}</h3>
      <div class="meta">
        <span class="pill">${esc(client)}</span>
        <span class="pill">${esc(demandaStatusLabel(item.status))}</span>
        ${item.priority === 'alta' ? '<span class="pill alta">Alta</span>' : ''}
        ${late ? '<span class="pill late">Prazo vencido</span>' : ''}
        ${item.origem ? `<span>${esc(item.origem)}</span>` : ''}
      </div>
    </article>
  `;
}

function renderGroups(title, groups, renderItem) {
  if (!groups.length) return '';
  return `
    <section>
      <h2 class="group-title">${esc(title)}</h2>
      ${groups
        .map(
          (g) => `
        <div class="group">
          <p class="group-title">${esc(g.name)} <span class="count">${g.items.length}</span></p>
          ${g.items.map(renderItem).join('')}
        </div>`
        )
        .join('')}
    </section>
  `;
}

function renderHojeSubNav() {
  const mode = state.prefs.hojeMode || 'all';
  const grupoCount = (state.grupos || []).length;
  const { tarefas, demandas } = filteredHoje();
  const taskCount = tarefas.length + demandas.length;
  const modes = [
    { id: 'all', label: 'Tudo' },
    { id: 'tarefas', label: 'Tarefas', count: taskCount },
    { id: 'grupos', label: 'Grupos', count: grupoCount, alert: grupoCount > 0 },
  ];
  return `
    <div class="hoje-subnav">
      ${modes
        .map((m) => {
          const badge =
            m.count != null && m.count > 0
              ? `<span class="subnav-count ${m.alert ? 'alert' : ''}">${m.count}</span>`
              : '';
          return `<button type="button" class="subnav-btn ${mode === m.id ? 'active' : ''}" data-hoje-mode="${m.id}">${esc(m.label)}${badge}</button>`;
        })
        .join('')}
    </div>`;
}

function renderHoje() {
  const mode = state.prefs.hojeMode || 'all';
  const showGrupos = mode === 'all' || mode === 'grupos';
  const showTarefas = mode === 'all' || mode === 'tarefas';
  const gruposCollapsed = Boolean(state.prefs.gruposCollapsed) && mode === 'all';
  const { tarefas, demandas } = filteredHoje();
  const taskGroups = api.groupByPerson(tarefas, state.lookups.people, api.firstAssignee);
  const demandaGroups = api.groupByPerson(demandas, state.lookups.people, (d) => d.owner_id);
  const peopleOpts = state.lookups.people
    .filter((p) => p.id !== state.profile?.id)
    .map((p) => `<option value="${esc(p.id)}" ${state.personFilter === p.id ? 'selected' : ''}>${esc(p.full_name || p.id)}</option>`)
    .join('');

  const tarefasBlock =
    !tarefas.length && !demandas.length
      ? '<div class="card empty">Nada para hoje neste recorte.</div>'
      : `<div class="card tarefas-card">
          ${renderGroups('Tarefas do dia', taskGroups, renderItemTask)}
          ${renderGroups('Demandas / solicitações', demandaGroups, renderItemDemanda)}
        </div>`;

  return `
    ${renderHojeSubNav()}
    ${
      showTarefas
        ? `<div class="card">
            <div class="filters">
              <div style="flex:1">
                <label for="person">Tarefas e demandas por pessoa</label>
                <select id="person">
                  <option value="all" ${state.personFilter === 'all' ? 'selected' : ''}>Todo o time</option>
                  <option value="${esc(state.profile?.id || '')}" ${state.personFilter === state.profile?.id ? 'selected' : ''}>Só eu</option>
                  ${peopleOpts}
                </select>
              </div>
              <button class="btn ghost small" type="button" id="reload" style="align-self:end">Atualizar</button>
            </div>
          </div>`
        : showGrupos
          ? `<div class="card filters-only">
              <button class="btn ghost small" type="button" id="reload">Atualizar grupos</button>
            </div>`
          : ''
    }
    ${state.error ? `<p class="err">${esc(state.error)}</p>` : ''}
    ${showGrupos ? renderGruposSemResposta(gruposCollapsed) : ''}
    ${showTarefas ? tarefasBlock : ''}
  `;
}

function renderGruposSemResposta(collapsed = false) {
  const grupos = state.grupos || [];
  if (!grupos.length) {
    return `
      <div class="card empty grupos-card">
        Nenhum grupo sem resposta agora. No WhatsApp Web a extensão olha a lista; a IA do Planeje marca quando alguém do grupo espera a equipe.
      </div>
    `;
  }
  const body = grupos
    .map((g) => {
      const ctx = g.contexto || {};
      return `
        <article class="item grupo-item" data-open-grupo="${esc(g.name)}" data-grupo-jid="${esc(g.chatJid || '')}" data-grupo-id="${esc(g.conversationId || g.id)}">
          <h3>${esc(g.name)}</h3>
          <div class="meta">
            <span class="pill late">${esc(g.source === 'ia' ? 'IA' : 'WhatsApp')}</span>
            ${g.unread ? `<span class="pill alta">${esc(g.unread)}</span>` : ''}
            ${g.cliente ? `<span class="pill">${esc(g.cliente)}</span>` : ''}
            <span>${esc(g.reason || 'Sem resposta')}</span>
          </div>
          ${g.preview ? `<p class="grupo-preview">${esc(g.preview)}</p>` : ''}
          <p class="grupo-contexto ${esc(ctx.kind || '')}">${esc(ctx.label || 'Analisando contexto do pedido…')}</p>
          <div class="grupo-actions">
            ${
              ctx.relatedType === 'tarefa' && ctx.relatedId
                ? `<button type="button" class="btn ghost small" data-open-related-task="${esc(ctx.relatedId)}">Abrir tarefa${ctx.relatedStatus ? ` (${esc(ctx.relatedStatus)})` : ''}</button>`
                : ''
            }
            ${
              ctx.relatedType === 'demanda'
                ? `<button type="button" class="btn ghost small" data-open-requests="1">Abrir demandas</button>`
                : ''
            }
            ${
              ctx.kind === 'pedido_sem_tarefa' || ctx.kind === 'sem_cliente' || ctx.kind === 'tem_tarefas'
                ? `<button type="button" class="btn small" data-criar-do-grupo="${esc(g.id)}">Criar tarefa deste pedido</button>`
                : ''
            }
          </div>
        </article>`;
    })
    .join('');

  return `
    <div class="card grupos-card collapsible ${collapsed ? 'is-collapsed' : ''}">
      <button type="button" class="collapse-head" id="toggle-grupos" aria-expanded="${collapsed ? 'false' : 'true'}">
        <span class="group-title">Grupos sem resposta <span class="count alert">${grupos.length}</span></span>
        <span class="collapse-chevron" aria-hidden="true">${collapsed ? '▸' : '▾'}</span>
      </button>
      <div class="collapse-body">${body}</div>
    </div>
  `;
}

function clientOptions(selected) {
  return api.clientsForCreate(state.lookups.clients)
    .map((c) => `<option value="${esc(c.id)}" ${selected === c.id ? 'selected' : ''}>${esc(c.empresa)}</option>`)
    .join('');
}

function peopleOptions(selected, { gestoresOnly = false } = {}) {
  const list = gestoresOnly
    ? state.lookups.people.filter((p) => p.role === 'admin' || p.role === 'superadmin')
    : state.lookups.people;
  const source = list.length ? list : state.lookups.people;
  return source
    .map((p) => `<option value="${esc(p.id)}" ${selected === p.id ? 'selected' : ''}>${esc(p.full_name || p.id)}</option>`)
    .join('');
}

function renderCriar() {
  const isTask = state.kind === 'tarefa';
  const clients = api.clientsForCreate(state.lookups.clients);
  const clientHint = !clients.length
    ? '<p class="err">Nenhum cliente operacional cadastrado. Cadastre o cliente no Planeje antes de criar.</p>'
    : '';
  return `
    <form class="card" id="create-form">
      <div class="kind-toggle">
        <button type="button" data-kind="tarefa" class="${isTask ? 'active' : ''}">Tarefa</button>
        <button type="button" data-kind="demanda" class="${!isTask ? 'active' : ''}">Demanda para o gestor</button>
      </div>
      ${clientHint}
      ${state.error ? `<p class="err">${esc(state.error)}</p>` : ''}
      ${state.notice ? `<p class="ok">${esc(state.notice)}</p>` : ''}
      <div class="field">
        <label for="title">Título</label>
        <input id="title" name="title" required value="${esc(state.form.title)}" />
      </div>
      <div class="field">
        <label for="client_id">Cliente</label>
        <select id="client_id" name="client_id" required>
          <option value="">Selecione</option>
          ${clientOptions(state.form.client_id)}
        </select>
      </div>
      ${
        isTask
          ? `
        <div class="row-2">
          <div class="field">
            <label for="type">Tipo</label>
            <select id="type" name="type">
              <option value="arte" ${state.form.type === 'arte' ? 'selected' : ''}>Arte</option>
              <option value="video" ${state.form.type === 'video' ? 'selected' : ''}>Vídeo</option>
              <option value="planejamento" ${state.form.type === 'planejamento' ? 'selected' : ''}>Planejamento</option>
              <option value="paid_traffic" ${state.form.type === 'paid_traffic' ? 'selected' : ''}>Tráfego</option>
              <option value="" ${state.form.type === '' ? 'selected' : ''}>Outro</option>
            </select>
          </div>
          <div class="field">
            <label for="due_date">Entrega</label>
            <input id="due_date" name="due_date" type="date" required value="${esc(state.form.due_date)}" />
          </div>
        </div>
        <div class="row-2">
          <div class="field">
            <label for="assignee_id">Responsável</label>
            <select id="assignee_id" name="assignee_id">${peopleOptions(state.form.assignee_id)}</select>
          </div>
          <div class="field">
            <label for="priority_task">Prioridade</label>
            <select id="priority_task" name="priority_task">
              <option value="low" ${state.form.priority_task === 'low' ? 'selected' : ''}>Baixa</option>
              <option value="medium" ${state.form.priority_task === 'medium' ? 'selected' : ''}>Média</option>
              <option value="high" ${state.form.priority_task === 'high' ? 'selected' : ''}>Alta</option>
            </select>
          </div>
        </div>`
          : `
        <div class="row-2">
          <div class="field">
            <label for="gestor_id">Gestor</label>
            <select id="gestor_id" name="gestor_id">${peopleOptions(state.form.gestor_id, { gestoresOnly: true })}</select>
          </div>
          <div class="field">
            <label for="prazo">Prazo</label>
            <input id="prazo" name="prazo" type="date" value="${esc(state.form.prazo)}" />
          </div>
        </div>
        <div class="field">
          <label for="priority_demanda">Prioridade</label>
          <select id="priority_demanda" name="priority_demanda">
            <option value="baixa" ${state.form.priority_demanda === 'baixa' ? 'selected' : ''}>Baixa</option>
            <option value="media" ${state.form.priority_demanda === 'media' ? 'selected' : ''}>Média</option>
            <option value="alta" ${state.form.priority_demanda === 'alta' ? 'selected' : ''}>Alta</option>
          </select>
        </div>`
      }
      <div class="field">
        <label for="description">Detalhes</label>
        <textarea id="description" name="description" placeholder="${isTask ? 'Opcional: briefing ou recado do grupo' : 'O que o gestor precisa resolver'}">${esc(state.form.description)}</textarea>
      </div>
      <div class="actions">
        <button class="btn ghost" type="button" id="use-selection">Usar texto marcado</button>
        <button class="btn" type="submit" ${state.saving ? 'disabled' : ''}>${state.saving ? 'Salvando…' : isTask ? 'Criar tarefa' : 'Enviar demanda'}</button>
      </div>
    </form>
  `;
}

function renderApp() {
  const cfgPromise = api.getCachedConfig();
  const waEmpty = !state.wa.chatName && !state.wa.selectedText;
  root.innerHTML = `
    <header class="top">
      <div class="brand">
        <img class="brand-mark" src="${asset('icons/icon48.png')}" alt="" />
        <div>
          <h1>Planeje</h1>
          <p>Demandas do dia em qualquer página</p>
        </div>
      </div>
      <div class="user-row">
        <div>
          <strong>${esc(state.profile?.full_name || state.profile?.email || '')}</strong>
          <div><span>${esc(state.profile?.role || '')}</span></div>
        </div>
        <div class="actions">
          <button class="btn ghost small" type="button" id="settings-btn">Ajustes</button>
          <button class="btn ghost small" type="button" id="logout">Sair</button>
        </div>
      </div>
      <div class="wa-chip ${waEmpty ? 'empty' : ''}">
        ${
          waEmpty
            ? 'No WhatsApp Web, o nome do chat e o texto marcado entram no formulário. Em qualquer outra página, o texto selecionado também vale.'
            : `<div><strong>${esc(state.wa.chatName || 'Chat')}</strong>${state.wa.selectedText ? `<div>${esc(state.wa.selectedText.slice(0, 140))}</div>` : ''}</div>`
        }
      </div>
    </header>
    <nav class="tabs">
      <button class="tab ${state.view === 'hoje' ? 'active' : ''}" data-view="hoje">Hoje</button>
      <button class="tab ${state.view === 'criar' ? 'active' : ''}" data-view="criar">Criar rápido</button>
    </nav>
    <main class="main">
      ${state.loading ? '<div class="card empty">Carregando…</div>' : state.view === 'hoje' ? renderHoje() : renderCriar()}
      ${
        state.settingsOpen
          ? `<form class="card settings" id="settings-form">
              <label for="appUrl">URL do Planeje</label>
              <input id="appUrl" name="appUrl" value="" />
              <label class="check-row"><input type="checkbox" name="notifyChanges" ${state.prefs.notifyChanges !== false ? 'checked' : ''} /> Avisar quando mudar etapa ou chegar mensagem</label>
              <label class="check-row"><input type="checkbox" name="alertGrupos" ${state.prefs.alertGrupos !== false ? 'checked' : ''} /> Alertar grupo sem resposta</label>
              <div class="actions">
                <button class="btn" type="submit">Salvar</button>
                <button class="btn ghost" type="button" id="close-settings">Fechar</button>
              </div>
            </form>`
          : ''
      }
    </main>
    <footer class="footer">Cria no Planeje: Tarefas (/tasks) e Solicitações (/requests).</footer>
  `;

  cfgPromise.then((cfg) => {
    const input = root.querySelector('#appUrl');
    if (input && !input.value) input.value = cfg.appUrl;
  });

  bindApp();
}

function readForm() {
  const form = root.querySelector('#create-form');
  if (!form) return;
  const data = new FormData(form);
  for (const [key, value] of data.entries()) state.form[key] = value;
  if (state.kind === 'tarefa' && !state.form.due_date) state.form.due_date = api.todayISO();
  if (state.kind === 'demanda' && !state.form.prazo) state.form.prazo = api.todayISO();
}

function bindApp() {
  root.querySelector('#logout')?.addEventListener('click', handleLogout);
  root.querySelector('#settings-btn')?.addEventListener('click', () => {
    state.settingsOpen = !state.settingsOpen;
    render();
  });
  root.querySelector('#close-settings')?.addEventListener('click', () => {
    state.settingsOpen = false;
    render();
  });
  root.querySelector('#settings-form')?.addEventListener('submit', handleSaveSettings);
  root.querySelectorAll('[data-view]').forEach((btn) =>
    btn.addEventListener('click', () => {
      readForm();
      setView(btn.dataset.view);
    })
  );
  root.querySelector('#toggle-grupos')?.addEventListener('click', async () => {
    state.prefs = await api.savePrefs({ gruposCollapsed: !state.prefs.gruposCollapsed });
    render();
  });
  root.querySelectorAll('[data-hoje-mode]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      state.prefs = await api.savePrefs({ hojeMode: btn.dataset.hojeMode });
      render();
    })
  );
  root.querySelector('#person')?.addEventListener('change', (e) => {
    state.personFilter = e.target.value;
    render();
  });
  root.querySelector('#reload')?.addEventListener('click', async () => {
    state.loading = true;
    render();
    try {
      await refreshData();
    } catch (err) {
      state.error = err.message;
    }
    state.loading = false;
    render();
  });
  root.querySelectorAll('[data-kind]').forEach((btn) =>
    btn.addEventListener('click', () => {
      readForm();
      const nextKind = btn.dataset.kind;
      if (nextKind === state.kind) return;
      state.kind = nextKind;
      const autoTitles = state.wa.chatName
        ? [`Pedido — ${state.wa.chatName}`, `Demanda — ${state.wa.chatName}`]
        : [];
      if (!state.form.title || autoTitles.includes(state.form.title)) {
        state.form.title = state.kind === 'demanda' ? `Demanda — ${state.wa.chatName}` : `Pedido — ${state.wa.chatName}`;
      }
      if (state.kind === 'tarefa' && !state.form.due_date) state.form.due_date = state.form.prazo || api.todayISO();
      if (state.kind === 'demanda' && !state.form.prazo) state.form.prazo = state.form.due_date || api.todayISO();
      applyWaToForm();
      render();
    })
  );
  root.querySelector('#create-form')?.addEventListener('submit', (e) => {
    readForm();
    handleCreate(e);
  });
  root.querySelector('#use-selection')?.addEventListener('click', () => {
    readForm();
    useSelection();
  });
  root.querySelectorAll('[data-open-task]').forEach((el) =>
    el.addEventListener('click', async () => {
      openUrl(await api.planejeUrl(`/tasks/list/${el.dataset.openTask}`));
    })
  );
  root.querySelectorAll('[data-open-requests]').forEach((el) =>
    el.addEventListener('click', async () => {
      openUrl(await api.planejeUrl('/requests'));
    })
  );
  root.querySelectorAll('[data-open-related-task]').forEach((el) =>
    el.addEventListener('click', async (event) => {
      event.stopPropagation();
      openUrl(await api.planejeUrl(`/tasks/list/${el.dataset.openRelatedTask}`));
    })
  );
  root.querySelectorAll('[data-criar-do-grupo]').forEach((el) =>
    el.addEventListener('click', (event) => {
      event.stopPropagation();
      const group = (state.grupos || []).find((item) => String(item.id) === String(el.dataset.criarDoGrupo));
      if (!group) return;
      const clients = api.clientsForCreate(state.lookups.clients);
      state.kind = 'tarefa';
      state.view = 'criar';
      state.error = '';
      state.notice = '';
      state.form.title = group.preview
        ? String(group.preview).replace(/^[^:]{1,40}:\s*/, '').slice(0, 80)
        : `Pedido — ${group.name}`;
      state.form.description = [group.preview, group.reason].filter(Boolean).join('\n\n');
      state.form.client_id = group.client_id || '';
      state.form.conversation_id = group.conversationId || '';
      state.form.whatsapp_chat_jid = group.chatJid || '';
      state.form.type = group.contexto?.suggestedType || api.guessPedidoType(`${group.preview || ''} ${group.reason || ''}`);
      state.form.due_date = state.form.due_date || api.todayISO();
      if (!state.form.client_id) {
        const match = api.matchClient(group.cliente || group.name, clients);
        if (match) state.form.client_id = match.id;
      }
      if (state.form.client_id && !clients.some((c) => c.id === state.form.client_id)) {
        state.form.client_id = '';
      }
      applyWaToForm();
      render();
    })
  );
  root.querySelectorAll('[data-open-grupo]').forEach((el) =>
    el.addEventListener('click', async (event) => {
      if (event.target.closest('button')) return;
      const name = el.dataset.openGrupo;
      const jid = el.dataset.grupoJid;
      if (name) {
        chrome.runtime?.sendMessage?.({ type: 'FOCUS_WA_CHAT', name }, () => void chrome.runtime.lastError);
      }
      const path = jid
        ? `/conversas/em-atendimento?chat=${encodeURIComponent(jid)}&audiencia=grupos`
        : '/conversas/em-atendimento?audiencia=grupos';
      openUrl(await api.planejeUrl(path));
    })
  );
}

function render() {
  if (!root) return;
  try {
    if (!state.session) {
      renderLogin();
      return;
    }
    renderApp();
  } catch (err) {
    root.innerHTML = `<p class="err">${esc(err.message || 'Falha ao desenhar o painel.')}</p>`;
  }
}

export function mountPlanejeApp(el) {
  root = el;
  boot();
}

if (document.documentElement.dataset.planejePanel === '1') {
  const pageRoot = document.getElementById('app');
  if (pageRoot) mountPlanejeApp(pageRoot);
}
